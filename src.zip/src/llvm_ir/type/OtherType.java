package llvm_ir.type;

public class OtherType extends LLvmType{
    public static OtherType BB = new OtherType();
    public static OtherType Function = new OtherType();
    public static OtherType Module = new OtherType();
}
