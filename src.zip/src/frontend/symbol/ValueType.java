package frontend.symbol;

public enum ValueType {
    INT,
    VOID;
}
